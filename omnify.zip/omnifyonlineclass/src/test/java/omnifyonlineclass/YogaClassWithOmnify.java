package omnifyonlineclass;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class YogaClassWithOmnify {
	
	WebDriver driver;
	
	
	@BeforeTest
	public void LanuchBrowser() throws Exception
	{
		WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();
		// Navigating to URL
		driver.get("https://app.getomnify.com/web/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//Login With google
		driver.findElement(By.xpath("//p[normalize-space()='Continue with Google']")).click();
		// Enter the Email Address
		driver.findElement(By.xpath("//*[@id=\"identifierId\"]")).sendKeys("prashanthma.92@gmail.com");
		// Enter the Password
		
		driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button/div[3]")).click();
		
		
	}

	@Test
	public void Creatclass()
	{
		// Click on the service
		driver.findElement(By.xpath("//div[@role='main']//a[@class='main-navigation-link w-inline-block ng-star-inserted is-selected w--current']//div[1]")).click();
		// click on create serive
		driver.findElement(By.xpath("//button[@class='page-header__cta services w-inline-block']")).click();
		
		driver.findElement(By.xpath("//div[@class='service-template-heading'][normalize-space()='Classes']")).click();
		
		//Basic Details
		
		driver.findElement(By.xpath("//*[@id=\"title\"]")).sendKeys("Onlineclass with omnify");
		driver.findElement(By.xpath("//div[@class='ql-editor ql-blank']")).sendKeys(" class will start sharp 9am IST");
		//color selection  
		driver.findElement(By.xpath("//div[@class='form-color-picker__option ng-star-inserted is-selected']//input[@id='radio-6']")).isSelected();
		
		//class Details
		WebElement Dropdown = driver.findElement(By.xpath("//div[@class='mat-form-field-wrapper ng-tns-c135-1']"));
		Select select = new Select(Dropdown);
		select.selectByIndex(2);
		driver.findElement(By.xpath("//input[@id='mat-input-9']")).sendKeys("omnify Banaglore");
		
		//class schedule
		
		WebElement Dropdown2 = driver.findElement(By.xpath("//div[@class='mat-select-panel-wrap ng-tns-c140-10 ng-trigger ng-trigger-transformPanelWrap ng-star-inserted']"));
		Select select2 = new Select(Dropdown);
		select2.selectByIndex(1);
		
		WebElement Dropdown3 = driver.findElement(By.xpath("//div[@class='mat-select-panel-wrap ng-tns-c140-12 ng-trigger ng-trigger-transformPanelWrap ng-star-inserted']"));
		Select select3 = new Select(Dropdown);
		select2.selectByIndex(1);
		
		WebElement Dropdown4 = driver.findElement(By.xpath("//div[@class='mat-select-panel-wrap ng-tns-c140-12 ng-trigger ng-trigger-transformPanelWrap ng-star-inserted']"));
		Select select4 = new Select(Dropdown);
		select2.selectByIndex(1);
		
	}
	
	@AfterTest
	public void Teardown()
	{
		
		driver.quit();
	}
}
